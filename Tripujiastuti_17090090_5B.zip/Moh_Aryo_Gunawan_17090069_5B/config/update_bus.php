<?php

	include 'koneksi.php';
	$id  = $_POST['id_bus'];
	$nama_bus	= $_POST['nama_bus'];
	$kelas	= $_POST['kelas'];
	$harga	= $_POST['harga'];
    $rute   = $_POST['rute'];
    $jadwal   = $_POST['jadwal'];

	$update 	= "UPDATE bus SET nama_bus='$nama_bus', kelas='$kelas', harga='$harga', rute='$rute', jadwal='$jadwal' WHERE id_bus='$id'";
	$updatebus	= mysqli_query($conn, $update)or die(mysqli_error());

if ($updatebus)
    {
    	echo "<strong><center>Data Berhasil Diubah";
    	echo '<META HTTP-EQUIV="REFRESH" CONTENT = "1; URL=../admin/admin.php?halaman=manajemen_bus">';
    }
else {
    	//echo "<strong><center>Data Gagal Diubah";
    	//echo '<META HTTP-EQUIV="REFRESH" CONTENT = "1; URL=../index.php?halaman=edit_info">';
    	print"
    		<script>
    			alert(\"Data Gagal Diubah!\");
    			history.back(-1);
    		</script>";
    }
?>