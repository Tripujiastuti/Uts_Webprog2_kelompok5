<?php

	$hostname = "localhost";
	$username = "root";
	$password = "";
	$database = "sumberalam";

	$conn = mysqli_connect($hostname,$username,$password,$database);

?>